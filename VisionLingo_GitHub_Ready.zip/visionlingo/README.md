# VisionLingo — Silent-Video Lip Reading

VisionLingo is a computer-vision and deep-learning project intended to recognize spoken words from silent video clips. The current Phase 1–2 codebase establishes dataset handling, speaker-level data splitting, mouth-region preprocessing, caching, and preprocessing augmentation.

## Current repository scope

- Dataset discovery and loading utilities
- Speaker-independent train/validation/test splitting
- Face and mouth-region extraction with OpenCV
- Frame sampling and sequence preparation
- Preprocessing cache utilities
- Image augmentation utilities
- Dataset exploration and preprocessing scripts
- Pytest-based tests for the implemented modules

**Important:** These two ZIPs contain the Phase 1 and Phase 2 implementation only. They do not establish that model training, final prediction, a web interface, or deployment is complete. Do not describe those features as finished until later phases are implemented and tested.

## Dataset

The project configuration expects the MIRACL-VC1 dataset at:

```text
data/MIRACL-VC1/
```

Expected layout:

```text
data/MIRACL-VC1/<speaker>/words/<word_id>/<instance>/color_001.jpg
```

The dataset is not included in this repository. Obtain it from its official distribution and review its terms before use. Keep dataset files out of Git.

## Setup

Python 3.10+ is recommended.

```bash
git clone https://github.com/Anushkaa08/VisionLingo.git
cd VisionLingo/visionlingo
python -m venv .venv
```

Activate the virtual environment:

```bash
# Windows
.venv\\Scripts\\activate

# macOS / Linux
source .venv/bin/activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

## Explore and preprocess data

From the `visionlingo/` project directory:

```bash
python scripts/explore_dataset.py
python scripts/preprocess_dataset.py
```

For preprocessing visualization:

```bash
python scripts/visualize_preprocessing.py
```

Run tests:

```bash
pytest
```

## Configuration

Tunable paths and preprocessing settings are in `configs/config.yaml`, including dataset root, speaker split seed, image size, sequence length, cache directory, face/mouth crop parameters, and augmentation settings.

## Project structure

```text
visionlingo/
├── configs/
├── data/                 # dataset instructions; dataset itself is excluded
├── docs/
├── scripts/
├── src/visionlingo/
│   ├── data/
│   └── preprocessing/
├── tests/
├── .gitignore
├── pytest.ini
└── requirements.txt
```

## Status

- [x] Phase 1: dataset utilities, speaker splits, initial tests and configuration
- [x] Phase 2: preprocessing pipeline, mouth extraction, sampling, caching, augmentation and tests
- [ ] Model architecture and training
- [ ] Evaluation and inference
- [ ] User interface and deployment

Update this checklist only after each phase is implemented and verified.
